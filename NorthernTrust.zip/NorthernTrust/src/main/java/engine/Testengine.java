package engine;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.Base;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class Testengine {
	public static AndroidDriver<AndroidElement> driver;
	public static AppiumDriverLocalService service;
	public Properties prop;
	public static Workbook book;
    public static Sheet sheet;
    public Base base;
    public AndroidElement element;
	
	public final String Testware_Path=System.getProperty("user.dir")+"\\src\\main\\java\\testware\\Testware.xlsx";
	
    public void startExecution(String sheetName) throws RuntimeException, IOException, InterruptedException{
		String locatorName = null;
	     String locatorValue = null;
		FileInputStream fis=new FileInputStream(Testware_Path);
		book=WorkbookFactory.create(fis);
		sheet=book.getSheet(sheetName);
		int k=0;
		for(int i=0;i<sheet.getLastRowNum();i++) 
				{
					try {
						String locatorColValue=sheet.getRow(i+1).getCell(k+1).toString().trim();
						if(!locatorColValue.equalsIgnoreCase("NA")) {
							 locatorName = locatorColValue.split("//")[0].trim();
							System.out.println(locatorName);
							 locatorValue = locatorColValue.split("//")[1].trim();
							System.out.println(locatorValue);
							}
						String action=sheet.getRow(i+1).getCell(k+2).toString().trim();
						System.out.println(action);
						String value=sheet.getRow(i+1).getCell(k+3).toString().trim();
						System.out.println(value);
						
						switch(action) {
						case "LaunchApplication":
							base =new Base();
							prop=base.init_properties();
							//base.init_driver(AppName, DeviceName);
							if(value.isEmpty()|| value.equals("NA"))
							{
								service=base.startServer();
								System.out.println(prop.getProperty("device"));
								driver=base.capabilities(prop.getProperty("GeneralStoreApp"),prop.getProperty("device") );
							}else
							{
								service=base.startServer();
								driver=base.capabilities(value, prop.getProperty("device"));
							}
							
							break;
						case "ScrollToText":
									
							break;
						case "CloseApp":
								//base.init_driver(value, prop.getProperty("device")).closeApp();
								driver.closeApp();
							break;
						default:
							break;
											}
						switch(locatorName)
						{
						case "id":
							 element=driver.findElement(By.id(locatorValue));
								if(action.equalsIgnoreCase("sendkeys"))
								{
									element.clear();
									element.sendKeys(value);
								} else if(action.equalsIgnoreCase("Click"))
								{
								element.click();
								}	
								locatorName=null;
							break;
						case "xpath":
							 element=driver.findElement(By.xpath(locatorValue));
							if(action.equalsIgnoreCase("Click"))
							{
								element.click();
							}
							locatorName=null;
						
						
					}
					}
					catch(Exception e){}
	}

}
    }
