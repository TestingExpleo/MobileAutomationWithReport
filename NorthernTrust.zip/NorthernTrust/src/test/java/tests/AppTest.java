package tests;

import java.io.IOException;

import org.testng.annotations.Test;

public class AppTest {

	public engine.Testengine Testengine;
	
	@Test
	public void TestApp()
	{
		
		Testengine = new engine.Testengine();
		try {
			Testengine.startExecution("sheet1");
		} catch (RuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
